Git is a distributed version control system.
Git is free software distributed under the GPL.
